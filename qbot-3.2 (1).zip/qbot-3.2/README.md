# qbot
This is a really cool roblox rank bot that I made! It is open source, so feel free to use it for your server/bot.

Acknowledgements: https://github.com/yogurtsyum/qbot/blob/master/acknowledgements.md

# Please note I am not responsible for if anything happens to your bot account. It is your responsibility to keep the cookie away from anyone you don't trust. Please also note that sharing your bot account cookie with this script will process it through noblox.js. Do not share your config.json file with anyone once filled out.

# Instructions at https://qbot.lengo.codes
